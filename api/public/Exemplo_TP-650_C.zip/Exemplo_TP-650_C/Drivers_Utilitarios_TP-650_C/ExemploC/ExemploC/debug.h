#pragma once
#include <stdio.h>

#define DVARI(x) printf("DVARI|%s:%d|[%s]: %d\n", __FUNCTION__,__LINE__,#x,x);
#define DVARH(x) printf("DVARI|%s:%d|[%s]: %x\n", __FUNCTION__,__LINE__,#x,x);