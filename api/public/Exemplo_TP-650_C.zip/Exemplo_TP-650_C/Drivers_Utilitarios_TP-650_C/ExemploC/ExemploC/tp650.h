#pragma once

#include "stdio.h"

typedef struct _tcmd
{
	char* b;
	size_t len;
} t_cmd;

t_cmd* tp_codEAN13(const char* cod);
t_cmd* tp_codEAN8(const char* cod);
t_cmd* tp_codUPCA(const char* cod);
t_cmd* tp_cod128(const char* cod);
t_cmd* tp_alturaCodBarras(int altura);
t_cmd* tp_textoNegrito(const char* texto);
t_cmd* tp_textoCondensado(const char* texto);
t_cmd* tp_cortePapel();
t_cmd* tp_qrcode(int qrsize, const char* data);
t_cmd* tp_abreGaveta(int pino, int pulso);
t_cmd* tp_pedeStatusDrawer();
t_cmd* tp_pedeStatusBotaoFeed();
t_cmd* tp_pedeStatusPapelTampa();
t_cmd* tp_pedeStatusNivelPapel();
int tp_drawerOn(char status);
int tp_botaoFeedPressed(char status);
int tp_papelTampaOK(char status);
int tp_nivelPapeOK(char status);