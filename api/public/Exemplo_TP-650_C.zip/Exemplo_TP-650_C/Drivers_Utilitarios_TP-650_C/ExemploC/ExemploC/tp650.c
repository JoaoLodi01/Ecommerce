#include "tp650.h"
#include "string.h"

char b[10 * 1024];
t_cmd cmd = { b,0 };

t_cmd* tp_codEAN13(const char* cod)
{	
	memset(cmd.b, 0, sizeof(b));
	cmd.b[0] = 0x1d;
	cmd.b[1] = 0x6b;
	cmd.b[2] = 0x02;
	int len = strlen(cod);
	strcpy(b + 3, cod);
	cmd.len = len + 4;
	return &cmd;
}

t_cmd* tp_codEAN8(const char* cod)
{
	memset(cmd.b, 0, sizeof(b));
	cmd.b[0] = 0x1d;
	cmd.b[1] = 0x6b;
	cmd.b[2] = 0x03;
	int len = strlen(cod);
	strcpy(b + 3, cod);
	cmd.len = len + 4;
	return &cmd;
}

t_cmd* tp_codUPCA(const char* cod)
{
	memset(cmd.b, 0, sizeof(b));
	cmd.b[0] = 0x1d;
	cmd.b[1] = 0x6b;
	cmd.b[2] = 0x00;
	int len = strlen(cod);
	strcpy(b + 3, cod);
	cmd.len = len + 4;
	return &cmd;
}

t_cmd* tp_cod128(const char* cod)
{
	memset(cmd.b, 0, sizeof(b));
	cmd.b[0] = 0x1d;
	cmd.b[1] = 0x6b;
	cmd.b[2] = 0x49;
	int len = strlen(cod);
	cmd.b[3] = (char)(len + 2);
	strcpy(b + 4, cod);
	cmd.len = len + 5;
	return &cmd;
}

t_cmd* tp_alturaCodBarras(int altura) 
{
	memset(cmd.b, 0, sizeof(b));
	cmd.b[0] = 0x1d;
	cmd.b[1] = 0x68;
	cmd.b[2] = (char)altura;
	cmd.len = 3;
	return &cmd;
}

t_cmd* tp_textoNegrito(const char* texto)
{
	memset(cmd.b, 0, sizeof(b));
	cmd.b[0] = 0x1b;
	cmd.b[1] = 0x21;
	cmd.b[2] = 0x00;
	cmd.b[3] = 0x1b;
	cmd.b[4] = 0x47;
	cmd.b[5] = (char)0xff;
	int len = strlen(texto);
	strcpy(cmd.b + 6, texto);
	cmd.b[len + 5 + 1] = 0x1b;
	cmd.b[len + 5 + 2] = 0x47;
	cmd.b[len + 5 + 3] = 0x00;
	cmd.len = 6 + len + 3;
	return &cmd;
}

t_cmd* tp_textoCondensado(const char* texto)
{
	memset(cmd.b, 0, sizeof(b));
	cmd.b[0] = 0x1b;
	cmd.b[1] = 0x21;
	cmd.b[2] = 0x00;
	cmd.b[3] = 0x1b;
	cmd.b[4] = 0x4d;
	cmd.b[5] = 0x01;
	int len = strlen(texto);
	strcpy(cmd.b + 6, texto);
	cmd.b[len + 5 + 1] = 0x1b;
	cmd.b[len + 5 + 2] = 0x4d;
	cmd.b[len + 5 + 3] = 0x00;
	cmd.len = 6 + len + 3;
	return &cmd;
}

t_cmd* tp_cortePapel() 
{
	static t_cmd c = { "\x1b\x6d", 2 };
	return &c;
}

t_cmd* tp_abreGaveta(int pino, int pulso) 
{
	memset(cmd.b, 0, sizeof(b));
	cmd.b[0] = 0x10;
	cmd.b[1] = 0x14;
	cmd.b[2] = 0x01;
	cmd.b[3] = (char)pino;
	cmd.b[4] = (char)pulso;
	cmd.len = 5;
	return &cmd;
}

t_cmd* tp_qrcode(int qrsize, const char* data) 
{
	int len = strlen(data);
	int l = len + 3;
	memset(cmd.b, 0, sizeof(b));
	//function 65 - mode
	memcpy(cmd.b, "\x1d\x28\x6b\x04\x00\x31\x41\x32\x00", 9);
	//function 67 - size
	memcpy(cmd.b + 9, "\x1d\x28\x6b\x03\x00\x31\x43", 7);
	cmd.b[9 + 7] = (char)qrsize;
	//function 80 - save data        
	cmd.b[9 + 8 + 0] = 0x1d;
	cmd.b[9 + 8 + 1] = 0x28;
	cmd.b[9 + 8 + 2] = 0x6b;
	cmd.b[9 + 8 + 3] = (char)(l % 256);
	cmd.b[9 + 8 + 4] = (char)(l / 256);
	cmd.b[9 + 8 + 5] = 0x31;
	cmd.b[9 + 8 + 6] = 0x50;
	cmd.b[9 + 8 + 7] = 0x30;
	strcpy(cmd.b + 9 + 8 + 8, data);
	//function 81 - print data
	memcpy(cmd.b + 9 + 8 + 8 + len, "\x1d\x28\x6b\x03\x00\x31\x51\x30", 8);
	cmd.len = 9 + 8 + 8 + len + 8;
	return &cmd;
}

t_cmd* tp_pedeStatusDrawer() 
{
	static t_cmd c = { "\x10\x04\x01", 3 };
	return &c;
}
t_cmd* tp_pedeStatusBotaoFeed() 
{
	static t_cmd c = { "\x10\x04\x02", 3 };
	return &c;
}
t_cmd* tp_pedeStatusPapelTampa() 
{
	static t_cmd c = { "\x10\x04\x04", 3 };
	return &c;
}
t_cmd* tp_pedeStatusNivelPapel() 
{
	static t_cmd c = { "\x1d\x72\x01", 3 };
	return &c;
}
int tp_drawerOn(char status) 
{
	return (status & 0b10111) != 0b10111;
}
int tp_botaoFeedPressed(char status) 
{
	return (status & 0b11111) == 0b11010;
}
int tp_papelTampaOK(char status) 
{
	return (status & 0b1110011) != 0b1110010;
}
int tp_nivelPapeOK(char status) 
{
	return (status & 0b11100) != 0b01100;
}