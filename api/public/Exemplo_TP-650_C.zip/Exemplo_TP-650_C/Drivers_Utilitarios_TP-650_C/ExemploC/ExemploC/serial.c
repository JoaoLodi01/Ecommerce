// https://msdn.microsoft.com/en-us/library/ff802693.aspx#serial_topic1

#include <windows.h>
#include <stdio.h>

#include "debug.h"
#include "serial.h"


HANDLE hSerial = 0;
DCB dcbSerialParams = { 0 };
COMMTIMEOUTS timeouts = { 0 };


BOOL WriteABuffer(char * lpBuf, DWORD dwToWrite);

BOOL WriteABuffer(char * lpBuf, DWORD dwToWrite)
{
	OVERLAPPED osWrite = { 0 };
	DWORD dwWritten;
	DWORD dwRes;
	BOOL fRes;

	// Create this write operation's OVERLAPPED structure's hEvent.
	osWrite.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	if (osWrite.hEvent == NULL)
		// error creating overlapped event handle
		return FALSE;

	// Issue write.
	if (!WriteFile(hSerial, lpBuf, dwToWrite, &dwWritten, &osWrite)) {
		if (GetLastError() != ERROR_IO_PENDING) {
			// WriteFile failed, but isn't delayed. Report error and abort.
			fRes = FALSE;
		}
		else
			// Write is pending.
			dwRes = WaitForSingleObject(osWrite.hEvent, INFINITE);
		switch (dwRes)
		{
			// OVERLAPPED structure's event has been signaled. 
		case WAIT_OBJECT_0:
			if (!GetOverlappedResult(hSerial, &osWrite, &dwWritten, FALSE))
				fRes = FALSE;
			else
				// Write operation completed successfully.
				fRes = TRUE;
			break;

		default:
			// An error has occurred in WaitForSingleObject.
			// This usually indicates a problem with the
			// OVERLAPPED structure's event handle.
			fRes = FALSE;
			break;
		}
	}
   else
	   // WriteFile completed immediately.
	   fRes = TRUE;
	   CloseHandle(osWrite.hEvent);
	   return fRes;
}

int s_write_cmd(const t_cmd* cmd)
{
	return s_write(cmd->b, cmd->len);
}

int s_write_s(const char* buffer)
{
	return s_write(buffer, strlen(buffer));
}

int s_write(const char* buffer, size_t len)
{
	return WriteABuffer(buffer, len);
}

size_t s_in_queue()
{
	if (hSerial <= 0)
		return 0;
	DWORD flags = 0;
	COMSTAT comstat;
	memset(&comstat, 0, sizeof(comstat));
	ClearCommError(hSerial, &flags, &comstat);
	return comstat.cbInQue; 
}

int s_open(const char* port)
{
	int ret = 0;
	// Open the highest available serial port number
	hSerial = CreateFileA(
		"COM3", 
		GENERIC_READ | GENERIC_WRITE, 
		0, 
		NULL,
		OPEN_EXISTING, 
		FILE_FLAG_OVERLAPPED | FILE_ATTRIBUTE_NORMAL, 
		NULL);

	if (hSerial == INVALID_HANDLE_VALUE)
	{
		DVARI(GetLastError());
		return -1;
	}

	dcbSerialParams.DCBlength = sizeof(dcbSerialParams);
	if (GetCommState(hSerial, &dcbSerialParams) == 0)
	{
		ret = -2;
		goto END_OPEN;
	}
	dcbSerialParams.BaudRate = CBR_115200;
	dcbSerialParams.ByteSize = 8;
	dcbSerialParams.StopBits = ONESTOPBIT;
	dcbSerialParams.Parity = NOPARITY;
	if (SetCommState(hSerial, &dcbSerialParams) == 0)
	{
		ret = -3;
		goto END_OPEN;
	}
	timeouts.ReadIntervalTimeout = 50;
	timeouts.ReadTotalTimeoutConstant = 50;
	timeouts.ReadTotalTimeoutMultiplier = 10;
	timeouts.WriteTotalTimeoutConstant = 50;
	timeouts.WriteTotalTimeoutMultiplier = 10;
	if (SetCommTimeouts(hSerial, &timeouts) == 0)
	{
		ret = -4;
		goto END_OPEN;
	}

	return 0;
END_OPEN:
	CloseHandle(hSerial);
	hSerial = 0;
	return ret;
}

void s_clean_recv()
{
	PurgeComm(hSerial, PURGE_TXCLEAR | PURGE_TXABORT | PURGE_RXCLEAR | PURGE_RXABORT);
}

char s_read_byte()
{
	for (int i = 20; i-- && !s_in_queue();Sleep(125));

	OVERLAPPED osRead = { 0 };
	DWORD dwWritten;
	DWORD dwRes;
	BOOL fRes;

	// Create this write operation's OVERLAPPED structure's hEvent.
	osRead.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	char byte;
	DWORD rc;
	//int ret = ReadFile(hSerial, byte, 1, &rc, &osRead.hEvent);
	ReadFile(hSerial, &byte, 1, &rc, &osRead);
	CloseHandle(osRead.hEvent);
	DVARI(byte);
	return byte;
}
void s_close()
{
	CloseHandle(hSerial);
}