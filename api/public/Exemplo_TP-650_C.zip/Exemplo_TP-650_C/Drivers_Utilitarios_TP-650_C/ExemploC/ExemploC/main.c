#include <stdio.h>
#include "serial.h"

#include "debug.h"

void verificaStatus()
{
	s_clean_recv();
	s_write_cmd(tp_pedeStatusDrawer());
	if (tp_drawerOn(s_read_byte()))
		s_write_s("Drawer sig: ON\n");
	else
		s_write_s("Drawer sig: OFF\n");

	s_clean_recv();
	s_write_cmd(tp_pedeStatusBotaoFeed());
	if (tp_botaoFeedPressed(s_read_byte()))
		s_write_s("Feed papel: ON\n");
	else
		s_write_s("Feed papel: OFF\n");

	s_clean_recv();
	s_write_cmd(tp_pedeStatusPapelTampa());
	if (tp_papelTampaOK(s_read_byte()))
		s_write_s("Papel/tampa: OK\n");
	else
		s_write_s("Papel/tampa: NOK\n");

	s_clean_recv();
	s_write_cmd(tp_pedeStatusNivelPapel());
	if (tp_nivelPapeOK(s_read_byte()))
		s_write_s("Nivel papel: OK\n");
	else
		s_write_s("Nivel papel: NOK\n");
}

char porta[128];
int getCom()
{
	FILE* f = fopen("PORTA_COM.txt", "r");
	memset(porta, 0, sizeof(porta));
	if (!f)
		return -1;
	int r = fread(porta, 1, 200, f);
	fclose(f);
	if (!r)
		return -2;
	if (strstr(porta,"COM") != porta)
		return -3;
	return 0;
}

int main()
{
	int PORTA_OK = getCom();
	DVARI(PORTA_OK);
	if (PORTA_OK != 0)
	{
		printf("Erro ao procurar porta em 'PORTA_COM.txt': %d\n", PORTA_OK);
		system("pause");
		return -1;
	}

	PORTA_OK  = s_open(porta);
	if (PORTA_OK != 0)
	{
		printf("Erro ao abrir porta='%s': %d\n", porta, PORTA_OK);
		system("pause");
		return -2;
	}

	s_write_s("Exemplo C/C++\n");

	s_write_cmd(tp_textoNegrito("Exemplo texto em negrito"));
	s_write_s("\n");
	s_write_cmd(tp_textoCondensado("Exemplo texto condensado"));
	s_write_s("\n");

	s_write_s("STATUS: \n");
	verificaStatus();

	s_write_s("Exemplo QRCode. Tamanho: 8\n");
	s_write_cmd(tp_qrcode(8, "www.tanca.com.br"));

	s_write_s("Exemplo QRCode NFCe:\n");
	s_write_cmd(tp_qrcode(4, "http://www.sefaz.mt.gov.br/nfce/consultanfce?chNFe=51131003460900000290650010000000031000000031&nVersao=100&tpAmb=2&cDest=02801244147&dhEmi=323031332D31302D32345431363A32313A30332D30333A3030&vNF=1,00&vICMS=0,00&digVal=78764D34764E2B48586A735657516F653474415A547855547764383D&cIdToken=000001&cHashQRCode=7AF4285DA2D18133BEF9F9370AD4A185B2527AFB"));

	s_write_s("Exemplo QRCode SAT:\n");
	s_write_cmd(tp_qrcode(4, "35141146377222003730599000004630000853254753|20141105134843|637.00||H0iMysWjM9zOXjaxkpPjqk7Q0Fp4RFvWkC0jLngU8o/pg5WpjhiVU2i/7BnIDz/WU3bMd9Cg6qWHvyn11e+qE7VpUjfZFPiczrrxPOqke3kdaX3y2db0/xebRcLUn1+PO2fvKK/7tAPMUiXvb1YDH6DqHVBhoM5A7u3P5RZrHvl1dfaJumLbe5uejKmq4rDNdOI5EVReJ5q1O6asOzwd8O0JzUGIf9aSdcClKWY3Xqt+0IWGjX61Kb8bEobAe4wV69hPpCApoAwDzrjuB110aUa2Q2aR/X3GWgqs8GTNvwQVDYNexuo3Pk67uo/hUr8tLMb2K15SIqoCBfya6sUIvA=="));

	s_write_s("Exemplo code 128. Altura: 25\n");
	s_write_cmd(tp_alturaCodBarras(25));
	s_write_cmd(tp_cod128("0123456789"));

	s_write_s("Exemplo UPCA. Altura: 50\n");
	s_write_cmd(tp_alturaCodBarras(50));
	s_write_cmd(tp_codUPCA("12345678901"));

	s_write_s("Exemplo EAN13. Altura: 100\n");
	s_write_cmd(tp_alturaCodBarras(100));
	s_write_cmd(tp_codEAN13("123456789012"));

	s_write_s("Exemplo EAN8. Altura: 200\n");
	s_write_cmd(tp_alturaCodBarras(200));
	s_write_cmd(tp_codEAN8("1234567"));

	s_write_s("Abre gaveta:\n");
	s_write_cmd(tp_abreGaveta(0, 4));
	s_write_s("Exemplo Corte papel: \n");
	s_write_s("\n\n\n\n" );
	s_write_cmd(tp_cortePapel());

	s_close();

	return 0;
}