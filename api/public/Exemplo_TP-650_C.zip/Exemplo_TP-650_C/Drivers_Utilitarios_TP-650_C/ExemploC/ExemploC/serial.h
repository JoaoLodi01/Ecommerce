#pragma once
#include "tp650.h"

size_t s_in_queue();
int s_open(const char* port);
int s_write(const char* buffer, size_t len);
int s_write_s(const char* buffer);
int s_write_cmd(const t_cmd* cmd);
void s_clean_recv();
char s_read_byte();
void s_close();